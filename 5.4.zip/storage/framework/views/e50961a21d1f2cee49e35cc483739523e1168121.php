<?php $__env->startSection('body'); ?>

<br>
<?php echo $__env->make('todo.partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<a href="http://127.0.0.1:8000/todo/create" class="btn btn-info">Add New</a>	
<div class="col-lg-6 col-lg-offset-3">
	<center><h1>Form</h1></center>

	<ul class="list-group col-lg-8">

   <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     <li class="list-group-item d-flex justify-content-between align-items-center">
	<a href="<?php echo e('/todo/'.$todo->id); ?>"><?php echo e($todo->title); ?></a>
	<span class="pull-right"><?php echo e($todo->created_at->diffForHumans()); ?></span>
	 </li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</ul>

	<ul class="list-group col-lg-4">

   <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     <li class="list-group-item d-flex justify-content-between align-items-center">
	<a href="<?php echo e('/todo/'.$todo->id.'/edit'); ?>"><i class="fas fa-edit"></i></a>
<form class="form-goup pull-right" action="<?php echo e('/todo/'.$todo->id); ?>" method="post">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

<button type="submit" style="border:none;"><i class="fas fa-trash-alt"></i></button>
</form>
	 </li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</ul>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.newapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>