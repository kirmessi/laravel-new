<?php $__env->startSection('body'); ?>

<br>
<a href="/todo" class="btn btn-info">Back</a>
<div class="col-lg-4 col-lg-offset-4">
	<h1>Create New Item</h1>
	<form action="/todo" method="POST">
	<?php echo e(csrf_field()); ?>

  <fieldset>
   <div class="form-group">
  
    <input type="text" name="title" class="form-control" placeholder="title">
    </div>

    <div class="form-group">

      <textarea class="form-control" name="body" id="exampleTextarea" placeholder="message" rows="3"></textarea>
    </div>

   
    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>
<br>
<?php echo $__env->make('todo.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.newapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>