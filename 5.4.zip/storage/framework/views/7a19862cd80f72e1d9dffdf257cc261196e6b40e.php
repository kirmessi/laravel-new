<?php if(session()->has('message')): ?>
<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>