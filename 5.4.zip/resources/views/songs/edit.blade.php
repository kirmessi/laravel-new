@extends ('layout.app')
@section('body')
{{$song->title}} <br>
{{$song->artist}}
@endsection