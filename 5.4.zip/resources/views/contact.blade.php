@extends ('layout.app')
@section('title','About')
@section('body')
Contact
@endsection