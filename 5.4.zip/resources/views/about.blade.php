@extends ('layout.app')
@section('title','About')
@section('body')
About
@endsection